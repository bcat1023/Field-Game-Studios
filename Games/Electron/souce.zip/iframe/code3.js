gdjs.Level_323Code = {};
gdjs.Level_323Code.forEachCount0_3 = 0;

gdjs.Level_323Code.forEachCount1_3 = 0;

gdjs.Level_323Code.forEachIndex3 = 0;

gdjs.Level_323Code.forEachObjects3 = [];

gdjs.Level_323Code.forEachTotalCount3 = 0;

gdjs.Level_323Code.GDPlayerObjects1= [];
gdjs.Level_323Code.GDPlayerObjects2= [];
gdjs.Level_323Code.GDPlayerObjects3= [];
gdjs.Level_323Code.GDPlatformObjects1= [];
gdjs.Level_323Code.GDPlatformObjects2= [];
gdjs.Level_323Code.GDPlatformObjects3= [];
gdjs.Level_323Code.GDJumpthruObjects1= [];
gdjs.Level_323Code.GDJumpthruObjects2= [];
gdjs.Level_323Code.GDJumpthruObjects3= [];
gdjs.Level_323Code.GDTiledGrassPlatformObjects1= [];
gdjs.Level_323Code.GDTiledGrassPlatformObjects2= [];
gdjs.Level_323Code.GDTiledGrassPlatformObjects3= [];
gdjs.Level_323Code.GDTrapdoorObjects1= [];
gdjs.Level_323Code.GDTrapdoorObjects2= [];
gdjs.Level_323Code.GDTrapdoorObjects3= [];
gdjs.Level_323Code.GDDoorObjects1= [];
gdjs.Level_323Code.GDDoorObjects2= [];
gdjs.Level_323Code.GDDoorObjects3= [];
gdjs.Level_323Code.GDTiledCastlePlatformObjects1= [];
gdjs.Level_323Code.GDTiledCastlePlatformObjects2= [];
gdjs.Level_323Code.GDTiledCastlePlatformObjects3= [];
gdjs.Level_323Code.GDMovingPlatformObjects1= [];
gdjs.Level_323Code.GDMovingPlatformObjects2= [];
gdjs.Level_323Code.GDMovingPlatformObjects3= [];
gdjs.Level_323Code.GDGoRightObjects1= [];
gdjs.Level_323Code.GDGoRightObjects2= [];
gdjs.Level_323Code.GDGoRightObjects3= [];
gdjs.Level_323Code.GDGoLeftObjects1= [];
gdjs.Level_323Code.GDGoLeftObjects2= [];
gdjs.Level_323Code.GDGoLeftObjects3= [];
gdjs.Level_323Code.GDLadderObjects1= [];
gdjs.Level_323Code.GDLadderObjects2= [];
gdjs.Level_323Code.GDLadderObjects3= [];
gdjs.Level_323Code.GDPlayerHitBoxObjects1= [];
gdjs.Level_323Code.GDPlayerHitBoxObjects2= [];
gdjs.Level_323Code.GDPlayerHitBoxObjects3= [];
gdjs.Level_323Code.GDSlimeWalkObjects1= [];
gdjs.Level_323Code.GDSlimeWalkObjects2= [];
gdjs.Level_323Code.GDSlimeWalkObjects3= [];
gdjs.Level_323Code.GDFlyObjects1= [];
gdjs.Level_323Code.GDFlyObjects2= [];
gdjs.Level_323Code.GDFlyObjects3= [];
gdjs.Level_323Code.GDBackgroundObjectsObjects1= [];
gdjs.Level_323Code.GDBackgroundObjectsObjects2= [];
gdjs.Level_323Code.GDBackgroundObjectsObjects3= [];
gdjs.Level_323Code.GDLifeObjects1= [];
gdjs.Level_323Code.GDLifeObjects2= [];
gdjs.Level_323Code.GDLifeObjects3= [];
gdjs.Level_323Code.GDScoreObjects1= [];
gdjs.Level_323Code.GDScoreObjects2= [];
gdjs.Level_323Code.GDScoreObjects3= [];
gdjs.Level_323Code.GDCoinObjects1= [];
gdjs.Level_323Code.GDCoinObjects2= [];
gdjs.Level_323Code.GDCoinObjects3= [];
gdjs.Level_323Code.GDCoinIconObjects1= [];
gdjs.Level_323Code.GDCoinIconObjects2= [];
gdjs.Level_323Code.GDCoinIconObjects3= [];
gdjs.Level_323Code.GDLeftButtonObjects1= [];
gdjs.Level_323Code.GDLeftButtonObjects2= [];
gdjs.Level_323Code.GDLeftButtonObjects3= [];
gdjs.Level_323Code.GDRightButtonObjects1= [];
gdjs.Level_323Code.GDRightButtonObjects2= [];
gdjs.Level_323Code.GDRightButtonObjects3= [];
gdjs.Level_323Code.GDJumpButtonObjects1= [];
gdjs.Level_323Code.GDJumpButtonObjects2= [];
gdjs.Level_323Code.GDJumpButtonObjects3= [];
gdjs.Level_323Code.GDArrowButtonsBgObjects1= [];
gdjs.Level_323Code.GDArrowButtonsBgObjects2= [];
gdjs.Level_323Code.GDArrowButtonsBgObjects3= [];
gdjs.Level_323Code.GDCheckpointObjects1= [];
gdjs.Level_323Code.GDCheckpointObjects2= [];
gdjs.Level_323Code.GDCheckpointObjects3= [];
gdjs.Level_323Code.GDTopButtonObjects1= [];
gdjs.Level_323Code.GDTopButtonObjects2= [];
gdjs.Level_323Code.GDTopButtonObjects3= [];
gdjs.Level_323Code.GDPauseObjects1= [];
gdjs.Level_323Code.GDPauseObjects2= [];
gdjs.Level_323Code.GDPauseObjects3= [];
gdjs.Level_323Code.GDBottomButtonObjects1= [];
gdjs.Level_323Code.GDBottomButtonObjects2= [];
gdjs.Level_323Code.GDBottomButtonObjects3= [];
gdjs.Level_323Code.GDCheckpoint2Objects1= [];
gdjs.Level_323Code.GDCheckpoint2Objects2= [];
gdjs.Level_323Code.GDCheckpoint2Objects3= [];
gdjs.Level_323Code.GDgameOverObjects1= [];
gdjs.Level_323Code.GDgameOverObjects2= [];
gdjs.Level_323Code.GDgameOverObjects3= [];
gdjs.Level_323Code.GDNewObjectObjects1= [];
gdjs.Level_323Code.GDNewObjectObjects2= [];
gdjs.Level_323Code.GDNewObjectObjects3= [];
gdjs.Level_323Code.GDNewObject2Objects1= [];
gdjs.Level_323Code.GDNewObject2Objects2= [];
gdjs.Level_323Code.GDNewObject2Objects3= [];
gdjs.Level_323Code.GDNewObject3Objects1= [];
gdjs.Level_323Code.GDNewObject3Objects2= [];
gdjs.Level_323Code.GDNewObject3Objects3= [];
gdjs.Level_323Code.GDNewObject4Objects1= [];
gdjs.Level_323Code.GDNewObject4Objects2= [];
gdjs.Level_323Code.GDNewObject4Objects3= [];
gdjs.Level_323Code.GDNewObject5Objects1= [];
gdjs.Level_323Code.GDNewObject5Objects2= [];
gdjs.Level_323Code.GDNewObject5Objects3= [];
gdjs.Level_323Code.GDNewObject6Objects1= [];
gdjs.Level_323Code.GDNewObject6Objects2= [];
gdjs.Level_323Code.GDNewObject6Objects3= [];
gdjs.Level_323Code.GDDeath_95boxObjects1= [];
gdjs.Level_323Code.GDDeath_95boxObjects2= [];
gdjs.Level_323Code.GDDeath_95boxObjects3= [];
gdjs.Level_323Code.GDtextObjects1= [];
gdjs.Level_323Code.GDtextObjects2= [];
gdjs.Level_323Code.GDtextObjects3= [];
gdjs.Level_323Code.GDnumObjects1= [];
gdjs.Level_323Code.GDnumObjects2= [];
gdjs.Level_323Code.GDnumObjects3= [];
gdjs.Level_323Code.GDNewObject7Objects1= [];
gdjs.Level_323Code.GDNewObject7Objects2= [];
gdjs.Level_323Code.GDNewObject7Objects3= [];

gdjs.Level_323Code.conditionTrue_0 = {val:false};
gdjs.Level_323Code.condition0IsTrue_0 = {val:false};
gdjs.Level_323Code.condition1IsTrue_0 = {val:false};
gdjs.Level_323Code.condition2IsTrue_0 = {val:false};
gdjs.Level_323Code.conditionTrue_1 = {val:false};
gdjs.Level_323Code.condition0IsTrue_1 = {val:false};
gdjs.Level_323Code.condition1IsTrue_1 = {val:false};
gdjs.Level_323Code.condition2IsTrue_1 = {val:false};


gdjs.Level_323Code.eventsList0 = function(runtimeScene) {

{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_323Code.conditionTrue_1 = gdjs.Level_323Code.condition0IsTrue_0;
gdjs.Level_323Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11535748);
}
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "https://resources.gdevelop-app.com/examples/platformer/jump.wav", false, 100, 1);
}}

}


};gdjs.Level_323Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level_323Code.GDPlayerHitBoxObjects1, gdjs.Level_323Code.GDPlayerHitBoxObjects2);


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( !(gdjs.Level_323Code.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDPlayerHitBoxObjects2[k] = gdjs.Level_323Code.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs.Level_323Code.GDPlayerHitBoxObjects2.length = k;}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerObjects2[i].setAnimationName("Idle");
}
}}

}


{

/* Reuse gdjs.Level_323Code.GDPlayerHitBoxObjects1 */

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isMoving() ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDPlayerHitBoxObjects1[k] = gdjs.Level_323Code.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.Level_323Code.GDPlayerHitBoxObjects1.length = k;}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerObjects1[i].setAnimationName("Running");
}
}}

}


};gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDGoLeftObjects1Objects = Hashtable.newFrom({"GoLeft": gdjs.Level_323Code.GDGoLeftObjects1});gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDMovingPlatformObjects1Objects = Hashtable.newFrom({"MovingPlatform": gdjs.Level_323Code.GDMovingPlatformObjects1});gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDGoRightObjects1Objects = Hashtable.newFrom({"GoRight": gdjs.Level_323Code.GDGoRightObjects1});gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDMovingPlatformObjects1Objects = Hashtable.newFrom({"MovingPlatform": gdjs.Level_323Code.GDMovingPlatformObjects1});gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDGoLeftObjects2Objects = Hashtable.newFrom({"GoLeft": gdjs.Level_323Code.GDGoLeftObjects2});gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDSlimeWalkObjects2ObjectsGDgdjs_46Level_95323Code_46GDFlyObjects2Objects = Hashtable.newFrom({"SlimeWalk": gdjs.Level_323Code.GDSlimeWalkObjects2, "Fly": gdjs.Level_323Code.GDFlyObjects2});gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDGoRightObjects2Objects = Hashtable.newFrom({"GoRight": gdjs.Level_323Code.GDGoRightObjects2});gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDSlimeWalkObjects2ObjectsGDgdjs_46Level_95323Code_46GDFlyObjects2Objects = Hashtable.newFrom({"SlimeWalk": gdjs.Level_323Code.GDSlimeWalkObjects2, "Fly": gdjs.Level_323Code.GDFlyObjects2});gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDPlayerHitBoxObjects1Objects = Hashtable.newFrom({"PlayerHitBox": gdjs.Level_323Code.GDPlayerHitBoxObjects1});gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDSlimeWalkObjects1ObjectsGDgdjs_46Level_95323Code_46GDFlyObjects1Objects = Hashtable.newFrom({"SlimeWalk": gdjs.Level_323Code.GDSlimeWalkObjects1, "Fly": gdjs.Level_323Code.GDFlyObjects1});gdjs.Level_323Code.eventsList2 = function(runtimeScene) {

};gdjs.Level_323Code.eventsList3 = function(runtimeScene) {

{

/* Reuse gdjs.Level_323Code.GDFlyObjects2 */
/* Reuse gdjs.Level_323Code.GDSlimeWalkObjects2 */

gdjs.Level_323Code.forEachTotalCount3 = 0;
gdjs.Level_323Code.forEachObjects3.length = 0;
gdjs.Level_323Code.forEachCount0_3 = gdjs.Level_323Code.GDSlimeWalkObjects2.length;
gdjs.Level_323Code.forEachTotalCount3 += gdjs.Level_323Code.forEachCount0_3;
gdjs.Level_323Code.forEachObjects3.push.apply(gdjs.Level_323Code.forEachObjects3,gdjs.Level_323Code.GDSlimeWalkObjects2);
gdjs.Level_323Code.forEachCount1_3 = gdjs.Level_323Code.GDFlyObjects2.length;
gdjs.Level_323Code.forEachTotalCount3 += gdjs.Level_323Code.forEachCount1_3;
gdjs.Level_323Code.forEachObjects3.push.apply(gdjs.Level_323Code.forEachObjects3,gdjs.Level_323Code.GDFlyObjects2);
for(gdjs.Level_323Code.forEachIndex3 = 0;gdjs.Level_323Code.forEachIndex3 < gdjs.Level_323Code.forEachTotalCount3;++gdjs.Level_323Code.forEachIndex3) {
gdjs.Level_323Code.GDFlyObjects3.length = 0;

gdjs.Level_323Code.GDSlimeWalkObjects3.length = 0;


if (gdjs.Level_323Code.forEachIndex3 < gdjs.Level_323Code.forEachCount0_3) {
    gdjs.Level_323Code.GDSlimeWalkObjects3.push(gdjs.Level_323Code.forEachObjects3[gdjs.Level_323Code.forEachIndex3]);
}
else if (gdjs.Level_323Code.forEachIndex3 < gdjs.Level_323Code.forEachCount0_3+gdjs.Level_323Code.forEachCount1_3) {
    gdjs.Level_323Code.GDFlyObjects3.push(gdjs.Level_323Code.forEachObjects3[gdjs.Level_323Code.forEachIndex3]);
}
if (true) {
{runtimeScene.getVariables().getFromIndex(0).add(10);
}}
}

}


};gdjs.Level_323Code.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level_323Code.GDPlayerHitBoxObjects1, gdjs.Level_323Code.GDPlayerHitBoxObjects2);


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDPlayerHitBoxObjects2[k] = gdjs.Level_323Code.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs.Level_323Code.GDPlayerHitBoxObjects2.length = k;}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level_323Code.GDFlyObjects1, gdjs.Level_323Code.GDFlyObjects2);

/* Reuse gdjs.Level_323Code.GDPlayerHitBoxObjects2 */
gdjs.copyArray(gdjs.Level_323Code.GDSlimeWalkObjects1, gdjs.Level_323Code.GDSlimeWalkObjects2);

{for(var i = 0, len = gdjs.Level_323Code.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDSlimeWalkObjects2[i].setAnimation(1);
}
for(var i = 0, len = gdjs.Level_323Code.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDFlyObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Level_323Code.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDSlimeWalkObjects2[i].activateBehavior("PlatformerObject", true);
}
for(var i = 0, len = gdjs.Level_323Code.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDFlyObjects2[i].activateBehavior("PlatformerObject", true);
}
}{for(var i = 0, len = gdjs.Level_323Code.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").setGravity(1500);
}
for(var i = 0, len = gdjs.Level_323Code.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDFlyObjects2[i].getBehavior("PlatformerObject").setGravity(1500);
}
}{for(var i = 0, len = gdjs.Level_323Code.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level_323Code.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "https://resources.gdevelop-app.com/examples/platformer/jump.wav", false, 100, 1);
}
{ //Subevents
gdjs.Level_323Code.eventsList3(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level_323Code.GDPlayerHitBoxObjects1 */

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( !(gdjs.Level_323Code.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isFalling()) ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDPlayerHitBoxObjects1[k] = gdjs.Level_323Code.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.Level_323Code.GDPlayerHitBoxObjects1.length = k;}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(1);
}}

}


};gdjs.Level_323Code.eventsList5 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.Level_323Code.GDFlyObjects1, gdjs.Level_323Code.GDFlyObjects2);

gdjs.copyArray(runtimeScene.getObjects("GoLeft"), gdjs.Level_323Code.GDGoLeftObjects2);
gdjs.copyArray(gdjs.Level_323Code.GDSlimeWalkObjects1, gdjs.Level_323Code.GDSlimeWalkObjects2);


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDGoLeftObjects2Objects, gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDSlimeWalkObjects2ObjectsGDgdjs_46Level_95323Code_46GDFlyObjects2Objects, false, runtimeScene, false);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_323Code.GDFlyObjects2 */
/* Reuse gdjs.Level_323Code.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs.Level_323Code.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDSlimeWalkObjects2[i].returnVariable(gdjs.Level_323Code.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")).setNumber(1);
}
for(var i = 0, len = gdjs.Level_323Code.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDFlyObjects2[i].returnVariable(gdjs.Level_323Code.GDFlyObjects2[i].getVariables().get("GoingLeft")).setNumber(1);
}
}}

}


{

gdjs.copyArray(gdjs.Level_323Code.GDFlyObjects1, gdjs.Level_323Code.GDFlyObjects2);

gdjs.copyArray(runtimeScene.getObjects("GoRight"), gdjs.Level_323Code.GDGoRightObjects2);
gdjs.copyArray(gdjs.Level_323Code.GDSlimeWalkObjects1, gdjs.Level_323Code.GDSlimeWalkObjects2);


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDGoRightObjects2Objects, gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDSlimeWalkObjects2ObjectsGDgdjs_46Level_95323Code_46GDFlyObjects2Objects, false, runtimeScene, false);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_323Code.GDFlyObjects2 */
/* Reuse gdjs.Level_323Code.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs.Level_323Code.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDSlimeWalkObjects2[i].returnVariable(gdjs.Level_323Code.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")).setNumber(0);
}
for(var i = 0, len = gdjs.Level_323Code.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDFlyObjects2[i].returnVariable(gdjs.Level_323Code.GDFlyObjects2[i].getVariables().get("GoingLeft")).setNumber(0);
}
}}

}


{

gdjs.copyArray(gdjs.Level_323Code.GDFlyObjects1, gdjs.Level_323Code.GDFlyObjects2);

gdjs.copyArray(gdjs.Level_323Code.GDSlimeWalkObjects1, gdjs.Level_323Code.GDSlimeWalkObjects2);


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDSlimeWalkObjects2.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDSlimeWalkObjects2[i].getVariableNumber(gdjs.Level_323Code.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")) == 1 ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDSlimeWalkObjects2[k] = gdjs.Level_323Code.GDSlimeWalkObjects2[i];
        ++k;
    }
}
gdjs.Level_323Code.GDSlimeWalkObjects2.length = k;for(var i = 0, k = 0, l = gdjs.Level_323Code.GDFlyObjects2.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDFlyObjects2[i].getVariableNumber(gdjs.Level_323Code.GDFlyObjects2[i].getVariables().get("GoingLeft")) == 1 ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDFlyObjects2[k] = gdjs.Level_323Code.GDFlyObjects2[i];
        ++k;
    }
}
gdjs.Level_323Code.GDFlyObjects2.length = k;}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_323Code.GDFlyObjects2 */
/* Reuse gdjs.Level_323Code.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs.Level_323Code.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDFlyObjects2[i].addForce(-(300), 0, 0);
}
}{for(var i = 0, len = gdjs.Level_323Code.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level_323Code.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDFlyObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.Level_323Code.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDSlimeWalkObjects2[i].flipX(false);
}
for(var i = 0, len = gdjs.Level_323Code.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDFlyObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(gdjs.Level_323Code.GDFlyObjects1, gdjs.Level_323Code.GDFlyObjects2);

gdjs.copyArray(gdjs.Level_323Code.GDSlimeWalkObjects1, gdjs.Level_323Code.GDSlimeWalkObjects2);


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDSlimeWalkObjects2.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDSlimeWalkObjects2[i].getVariableNumber(gdjs.Level_323Code.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")) == 0 ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDSlimeWalkObjects2[k] = gdjs.Level_323Code.GDSlimeWalkObjects2[i];
        ++k;
    }
}
gdjs.Level_323Code.GDSlimeWalkObjects2.length = k;for(var i = 0, k = 0, l = gdjs.Level_323Code.GDFlyObjects2.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDFlyObjects2[i].getVariableNumber(gdjs.Level_323Code.GDFlyObjects2[i].getVariables().get("GoingLeft")) == 0 ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDFlyObjects2[k] = gdjs.Level_323Code.GDFlyObjects2[i];
        ++k;
    }
}
gdjs.Level_323Code.GDFlyObjects2.length = k;}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_323Code.GDFlyObjects2 */
/* Reuse gdjs.Level_323Code.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs.Level_323Code.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDFlyObjects2[i].addForce(300, 0, 0);
}
}{for(var i = 0, len = gdjs.Level_323Code.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
for(var i = 0, len = gdjs.Level_323Code.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDFlyObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.Level_323Code.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDSlimeWalkObjects2[i].flipX(true);
}
for(var i = 0, len = gdjs.Level_323Code.GDFlyObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDFlyObjects2[i].flipX(true);
}
}}

}


{



}


{

/* Reuse gdjs.Level_323Code.GDFlyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects1);
/* Reuse gdjs.Level_323Code.GDSlimeWalkObjects1 */

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDPlayerHitBoxObjects1Objects, gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDSlimeWalkObjects1ObjectsGDgdjs_46Level_95323Code_46GDFlyObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_323Code.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDPlayerHitBoxObjects1Objects = Hashtable.newFrom({"PlayerHitBox": gdjs.Level_323Code.GDPlayerHitBoxObjects1});gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs.Level_323Code.GDCoinObjects1});gdjs.Level_323Code.eventsList6 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level_323Code.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDScoreObjects1[i].setString("x " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}}

}


};gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDLeftButtonObjects2Objects = Hashtable.newFrom({"LeftButton": gdjs.Level_323Code.GDLeftButtonObjects2});gdjs.Level_323Code.eventsList7 = function(runtimeScene) {

{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


};gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDRightButtonObjects2Objects = Hashtable.newFrom({"RightButton": gdjs.Level_323Code.GDRightButtonObjects2});gdjs.Level_323Code.eventsList8 = function(runtimeScene) {

{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


};gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDTopButtonObjects2Objects = Hashtable.newFrom({"TopButton": gdjs.Level_323Code.GDTopButtonObjects2});gdjs.Level_323Code.eventsList9 = function(runtimeScene) {

{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateUpKey();
}
}{for(var i = 0, len = gdjs.Level_323Code.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateLadderKey();
}
}}

}


};gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDBottomButtonObjects2Objects = Hashtable.newFrom({"BottomButton": gdjs.Level_323Code.GDBottomButtonObjects2});gdjs.Level_323Code.eventsList10 = function(runtimeScene) {

{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateDownKey();
}
}}

}


};gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDJumpButtonObjects1Objects = Hashtable.newFrom({"JumpButton": gdjs.Level_323Code.GDJumpButtonObjects1});gdjs.Level_323Code.eventsList11 = function(runtimeScene) {

{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


};gdjs.Level_323Code.eventsList12 = function(runtimeScene) {

{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.isMobile());
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ArrowButtonsBg"), gdjs.Level_323Code.GDArrowButtonsBgObjects2);
gdjs.copyArray(runtimeScene.getObjects("BottomButton"), gdjs.Level_323Code.GDBottomButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Level_323Code.GDJumpButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftButton"), gdjs.Level_323Code.GDLeftButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightButton"), gdjs.Level_323Code.GDRightButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.Level_323Code.GDTopButtonObjects2);
{for(var i = 0, len = gdjs.Level_323Code.GDLeftButtonObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDLeftButtonObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.Level_323Code.GDRightButtonObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDRightButtonObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.Level_323Code.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDJumpButtonObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.Level_323Code.GDArrowButtonsBgObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDArrowButtonsBgObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.Level_323Code.GDTopButtonObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDTopButtonObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.Level_323Code.GDBottomButtonObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDBottomButtonObjects2[i].hide(false);
}
}}

}


{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LeftButton"), gdjs.Level_323Code.GDLeftButtonObjects2);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDLeftButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_323Code.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("RightButton"), gdjs.Level_323Code.GDRightButtonObjects2);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDRightButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_323Code.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("TopButton"), gdjs.Level_323Code.GDTopButtonObjects2);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDTopButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_323Code.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BottomButton"), gdjs.Level_323Code.GDBottomButtonObjects2);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDBottomButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_323Code.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Level_323Code.GDJumpButtonObjects1);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDJumpButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_323Code.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDPlayerHitBoxObjects2Objects = Hashtable.newFrom({"PlayerHitBox": gdjs.Level_323Code.GDPlayerHitBoxObjects2});gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDCheckpointObjects2Objects = Hashtable.newFrom({"Checkpoint": gdjs.Level_323Code.GDCheckpointObjects2});gdjs.Level_323Code.eventsList13 = function(runtimeScene) {

{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) == 0;
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "gameover", true);
}}

}


};gdjs.Level_323Code.eventsList14 = function(runtimeScene) {

{



}


{


{
{runtimeScene.getVariables().getFromIndex(4).sub(1);
}
{ //Subevents
gdjs.Level_323Code.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.Level_323Code.eventsList15 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Checkpoint"), gdjs.Level_323Code.GDCheckpointObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects2);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
gdjs.Level_323Code.condition1IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDPlayerHitBoxObjects2Objects, gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDCheckpointObjects2Objects, false, runtimeScene, false);
}if ( gdjs.Level_323Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_323Code.conditionTrue_1 = gdjs.Level_323Code.condition1IsTrue_0;
gdjs.Level_323Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11558900);
}
}}
if (gdjs.Level_323Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_323Code.GDCheckpointObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Checkpoint2"), gdjs.Level_323Code.GDCheckpoint2Objects2);
{runtimeScene.getVariables().getFromIndex(1).setNumber((( gdjs.Level_323Code.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.Level_323Code.GDCheckpointObjects2[0].getPointX("")));
}{runtimeScene.getVariables().getFromIndex(2).setNumber((( gdjs.Level_323Code.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.Level_323Code.GDCheckpointObjects2[0].getPointY("")));
}{for(var i = 0, len = gdjs.Level_323Code.GDCheckpoint2Objects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDCheckpoint2Objects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level_323Code.GDCheckpoint2Objects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDCheckpoint2Objects2[i].playAnimation();
}
}{for(var i = 0, len = gdjs.Level_323Code.GDCheckpoint2Objects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDCheckpoint2Objects2[i].resetTimer("animationsyst");
}
}{for(var i = 0, len = gdjs.Level_323Code.GDCheckpointObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDCheckpointObjects2[i].playAnimation();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Checkpoint2"), gdjs.Level_323Code.GDCheckpoint2Objects2);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDCheckpoint2Objects2.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDCheckpoint2Objects2[i].timerElapsedTime("animationsyst", 5) ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDCheckpoint2Objects2[k] = gdjs.Level_323Code.GDCheckpoint2Objects2[i];
        ++k;
    }
}
gdjs.Level_323Code.GDCheckpoint2Objects2.length = k;}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_323Code.GDCheckpoint2Objects2 */
{for(var i = 0, len = gdjs.Level_323Code.GDCheckpoint2Objects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDCheckpoint2Objects2[i].hide();
}
}}

}


{



}


{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 1;
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects2);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerHitBoxObjects2[i].setPosition(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)),gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) - (gdjs.Level_323Code.GDPlayerHitBoxObjects2[i].getHeight()));
}
}{runtimeScene.getVariables().getFromIndex(3).setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "life lost sound.wav", false, 100, 1);
}
{ //Subevents
gdjs.Level_323Code.eventsList14(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects2);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDPlayerHitBoxObjects2[i].getY() > 1000 ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDPlayerHitBoxObjects2[k] = gdjs.Level_323Code.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs.Level_323Code.GDPlayerHitBoxObjects2.length = k;}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(1);
}}

}


{



}


};gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDPauseObjects1Objects = Hashtable.newFrom({"Pause": gdjs.Level_323Code.GDPauseObjects1});gdjs.Level_323Code.eventsList16 = function(runtimeScene) {

{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Pause");
}}

}


};gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDPlayerHitBoxObjects1Objects = Hashtable.newFrom({"PlayerHitBox": gdjs.Level_323Code.GDPlayerHitBoxObjects1});gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDNewObject2Objects1Objects = Hashtable.newFrom({"NewObject2": gdjs.Level_323Code.GDNewObject2Objects1});gdjs.Level_323Code.eventsList17 = function(runtimeScene) {

{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(5)) == 3;
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("save", "level", 4);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "gamewin", true);
}}

}


{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(5)) >= 3;
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "gamewin", true);
}}

}


};gdjs.Level_323Code.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewObject2"), gdjs.Level_323Code.GDNewObject2Objects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects1);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDPlayerHitBoxObjects1Objects, gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDNewObject2Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_323Code.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_323Code.GDPlayerObjects1});gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDDeath_9595boxObjects1Objects = Hashtable.newFrom({"Death_box": gdjs.Level_323Code.GDDeath_95boxObjects1});gdjs.Level_323Code.eventsList19 = function(runtimeScene) {

{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) == 0;
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "gameover", true);
}}

}


};gdjs.Level_323Code.eventsList20 = function(runtimeScene) {

{



}


{


{
{runtimeScene.getVariables().getFromIndex(4).sub(1);
}
{ //Subevents
gdjs.Level_323Code.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.Level_323Code.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Death_box"), gdjs.Level_323Code.GDDeath_95boxObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDPlayerObjects1Objects, gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDDeath_9595boxObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerHitBoxObjects1[i].setPosition(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)),gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) - (gdjs.Level_323Code.GDPlayerHitBoxObjects1[i].getHeight()));
}
}{runtimeScene.getVariables().getFromIndex(3).setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "life lost sound.wav", false, 100, 1);
}
{ //Subevents
gdjs.Level_323Code.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_323Code.GDPlayerObjects1});gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDMovingPlatformObjects1Objects = Hashtable.newFrom({"MovingPlatform": gdjs.Level_323Code.GDMovingPlatformObjects1});gdjs.Level_323Code.eventsList22 = function(runtimeScene) {

{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Death_box"), gdjs.Level_323Code.GDDeath_95boxObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerHitBoxObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level_323Code.GDDeath_95boxObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDDeath_95boxObjects1[i].hide();
}
}{runtimeScene.getVariables().getFromIndex(5).setString("STOP: DO NOT CONTINUE. CONTACT DEV");
}{gdjs.evtTools.storage.readNumberFromJSONFile("save", "level", runtimeScene, runtimeScene.getVariables().getFromIndex(5));
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 0.5, "", 0);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerObjects1[i].setPosition((( gdjs.Level_323Code.GDPlayerHitBoxObjects1.length === 0 ) ? 0 :gdjs.Level_323Code.GDPlayerHitBoxObjects1[0].getPointX("")) - 12,(( gdjs.Level_323Code.GDPlayerHitBoxObjects1.length === 0 ) ? 0 :gdjs.Level_323Code.GDPlayerHitBoxObjects1[0].getPointY("")));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects1);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDPlayerHitBoxObjects1[k] = gdjs.Level_323Code.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.Level_323Code.GDPlayerHitBoxObjects1.length = k;}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerObjects1[i].setAnimationName("Jumping");
}
}
{ //Subevents
gdjs.Level_323Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects1);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDPlayerHitBoxObjects1[k] = gdjs.Level_323Code.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.Level_323Code.GDPlayerHitBoxObjects1.length = k;}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerObjects1[i].setAnimationName("Jumping");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects1);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDPlayerHitBoxObjects1[k] = gdjs.Level_323Code.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.Level_323Code.GDPlayerHitBoxObjects1.length = k;}if (gdjs.Level_323Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_323Code.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects1);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isOnLadder() ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDPlayerHitBoxObjects1[k] = gdjs.Level_323Code.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.Level_323Code.GDPlayerHitBoxObjects1.length = k;}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerObjects1[i].setAnimationName("Jumping");
}
}}

}


{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerObjects1[i].flipX(true);
}
}}

}


{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDPlayerObjects1[i].flipX(false);
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Level_323Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level_323Code.GDPlayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.Level_323Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level_323Code.GDPlayerObjects1[0].getPointY("")), "", 0);
}}

}


{



}


{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GoLeft"), gdjs.Level_323Code.GDGoLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("GoRight"), gdjs.Level_323Code.GDGoRightObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDGoLeftObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDGoLeftObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level_323Code.GDGoRightObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDGoRightObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoLeft"), gdjs.Level_323Code.GDGoLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("MovingPlatform"), gdjs.Level_323Code.GDMovingPlatformObjects1);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDGoLeftObjects1Objects, gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDMovingPlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_323Code.GDMovingPlatformObjects1 */
{for(var i = 0, len = gdjs.Level_323Code.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDMovingPlatformObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level_323Code.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDMovingPlatformObjects1[i].addForce(-(150), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoRight"), gdjs.Level_323Code.GDGoRightObjects1);
gdjs.copyArray(runtimeScene.getObjects("MovingPlatform"), gdjs.Level_323Code.GDMovingPlatformObjects1);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDGoRightObjects1Objects, gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDMovingPlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_323Code.GDMovingPlatformObjects1 */
{for(var i = 0, len = gdjs.Level_323Code.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDMovingPlatformObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level_323Code.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDMovingPlatformObjects1[i].addForce(150, 0, 1);
}
}}

}


{



}


{



}


{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.Level_323Code.GDFlyObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDFlyObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDFlyObjects1[i].activateBehavior("PlatformerObject", false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.Level_323Code.GDFlyObjects1);
gdjs.copyArray(runtimeScene.getObjects("SlimeWalk"), gdjs.Level_323Code.GDSlimeWalkObjects1);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( !(gdjs.Level_323Code.GDSlimeWalkObjects1[i].isCurrentAnimationName("Dead")) ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDSlimeWalkObjects1[k] = gdjs.Level_323Code.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.Level_323Code.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.Level_323Code.GDFlyObjects1.length;i<l;++i) {
    if ( !(gdjs.Level_323Code.GDFlyObjects1[i].isCurrentAnimationName("Dead")) ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDFlyObjects1[k] = gdjs.Level_323Code.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.Level_323Code.GDFlyObjects1.length = k;}if (gdjs.Level_323Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_323Code.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.Level_323Code.GDFlyObjects1);
gdjs.copyArray(runtimeScene.getObjects("SlimeWalk"), gdjs.Level_323Code.GDSlimeWalkObjects1);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
gdjs.Level_323Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDSlimeWalkObjects1[i].isCurrentAnimationName("Dead") ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDSlimeWalkObjects1[k] = gdjs.Level_323Code.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.Level_323Code.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.Level_323Code.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDFlyObjects1[i].isCurrentAnimationName("Dead") ) {
        gdjs.Level_323Code.condition0IsTrue_0.val = true;
        gdjs.Level_323Code.GDFlyObjects1[k] = gdjs.Level_323Code.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.Level_323Code.GDFlyObjects1.length = k;}if ( gdjs.Level_323Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( !(gdjs.Level_323Code.GDSlimeWalkObjects1[i].getBehavior("Tween").isPlaying("FadeOut")) ) {
        gdjs.Level_323Code.condition1IsTrue_0.val = true;
        gdjs.Level_323Code.GDSlimeWalkObjects1[k] = gdjs.Level_323Code.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.Level_323Code.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.Level_323Code.GDFlyObjects1.length;i<l;++i) {
    if ( !(gdjs.Level_323Code.GDFlyObjects1[i].getBehavior("Tween").isPlaying("FadeOut")) ) {
        gdjs.Level_323Code.condition1IsTrue_0.val = true;
        gdjs.Level_323Code.GDFlyObjects1[k] = gdjs.Level_323Code.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.Level_323Code.GDFlyObjects1.length = k;}}
if (gdjs.Level_323Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_323Code.GDFlyObjects1 */
/* Reuse gdjs.Level_323Code.GDSlimeWalkObjects1 */
{for(var i = 0, len = gdjs.Level_323Code.GDSlimeWalkObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDSlimeWalkObjects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "easeOutQuad", 1500, true);
}
for(var i = 0, len = gdjs.Level_323Code.GDFlyObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDFlyObjects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "easeOutQuad", 1500, true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Level_323Code.GDCoinObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerHitBox"), gdjs.Level_323Code.GDPlayerHitBoxObjects1);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
gdjs.Level_323Code.condition1IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDPlayerHitBoxObjects1Objects, gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDCoinObjects1Objects, false, runtimeScene, false);
}if ( gdjs.Level_323Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_323Code.GDCoinObjects1.length;i<l;++i) {
    if ( gdjs.Level_323Code.GDCoinObjects1[i].getOpacity() == 255 ) {
        gdjs.Level_323Code.condition1IsTrue_0.val = true;
        gdjs.Level_323Code.GDCoinObjects1[k] = gdjs.Level_323Code.GDCoinObjects1[i];
        ++k;
    }
}
gdjs.Level_323Code.GDCoinObjects1.length = k;}}
if (gdjs.Level_323Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_323Code.GDCoinObjects1 */
{for(var i = 0, len = gdjs.Level_323Code.GDCoinObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDCoinObjects1[i].setOpacity(254);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "https://resources.gdevelop-app.com/examples/platformer/coin.wav", false, 100, 1);
}{runtimeScene.getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.Level_323Code.GDCoinObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDCoinObjects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "easeInQuad", 700, true);
}
}{for(var i = 0, len = gdjs.Level_323Code.GDCoinObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDCoinObjects1[i].getBehavior("Tween").addObjectPositionYTween("MoveUp", (gdjs.Level_323Code.GDCoinObjects1[i].getPointY("")) - 50, "easeOutQuad", 700, false);
}
}}

}


{


gdjs.Level_323Code.eventsList6(runtimeScene);
}


{


gdjs.Level_323Code.eventsList12(runtimeScene);
}


{


gdjs.Level_323Code.eventsList15(runtimeScene);
}


{



}


{


gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(4)) == "nan";
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(4).setNumber(5);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Life"), gdjs.Level_323Code.GDLifeObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDLifeObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDLifeObjects1[i].setString("x " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Pause"), gdjs.Level_323Code.GDPauseObjects1);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDPauseObjects1Objects, runtimeScene, true, false);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_323Code.eventsList16(runtimeScene);} //End of subevents
}

}


{


gdjs.Level_323Code.eventsList18(runtimeScene);
}


{


gdjs.Level_323Code.eventsList21(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("MovingPlatform"), gdjs.Level_323Code.GDMovingPlatformObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_323Code.GDPlayerObjects1);

gdjs.Level_323Code.condition0IsTrue_0.val = false;
{
gdjs.Level_323Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDPlayerObjects1Objects, gdjs.Level_323Code.mapOfGDgdjs_46Level_95323Code_46GDMovingPlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level_323Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.Level_323Code.GDFlyObjects1);
gdjs.copyArray(runtimeScene.getObjects("SlimeWalk"), gdjs.Level_323Code.GDSlimeWalkObjects1);
{for(var i = 0, len = gdjs.Level_323Code.GDSlimeWalkObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDSlimeWalkObjects1[i].returnVariable(gdjs.Level_323Code.GDSlimeWalkObjects1[i].getVariables().get("GoingLeft")).setNumber(0);
}
for(var i = 0, len = gdjs.Level_323Code.GDFlyObjects1.length ;i < len;++i) {
    gdjs.Level_323Code.GDFlyObjects1[i].returnVariable(gdjs.Level_323Code.GDFlyObjects1[i].getVariables().get("GoingLeft")).setNumber(0);
}
}}

}


};

gdjs.Level_323Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_323Code.GDPlayerObjects1.length = 0;
gdjs.Level_323Code.GDPlayerObjects2.length = 0;
gdjs.Level_323Code.GDPlayerObjects3.length = 0;
gdjs.Level_323Code.GDPlatformObjects1.length = 0;
gdjs.Level_323Code.GDPlatformObjects2.length = 0;
gdjs.Level_323Code.GDPlatformObjects3.length = 0;
gdjs.Level_323Code.GDJumpthruObjects1.length = 0;
gdjs.Level_323Code.GDJumpthruObjects2.length = 0;
gdjs.Level_323Code.GDJumpthruObjects3.length = 0;
gdjs.Level_323Code.GDTiledGrassPlatformObjects1.length = 0;
gdjs.Level_323Code.GDTiledGrassPlatformObjects2.length = 0;
gdjs.Level_323Code.GDTiledGrassPlatformObjects3.length = 0;
gdjs.Level_323Code.GDTrapdoorObjects1.length = 0;
gdjs.Level_323Code.GDTrapdoorObjects2.length = 0;
gdjs.Level_323Code.GDTrapdoorObjects3.length = 0;
gdjs.Level_323Code.GDDoorObjects1.length = 0;
gdjs.Level_323Code.GDDoorObjects2.length = 0;
gdjs.Level_323Code.GDDoorObjects3.length = 0;
gdjs.Level_323Code.GDTiledCastlePlatformObjects1.length = 0;
gdjs.Level_323Code.GDTiledCastlePlatformObjects2.length = 0;
gdjs.Level_323Code.GDTiledCastlePlatformObjects3.length = 0;
gdjs.Level_323Code.GDMovingPlatformObjects1.length = 0;
gdjs.Level_323Code.GDMovingPlatformObjects2.length = 0;
gdjs.Level_323Code.GDMovingPlatformObjects3.length = 0;
gdjs.Level_323Code.GDGoRightObjects1.length = 0;
gdjs.Level_323Code.GDGoRightObjects2.length = 0;
gdjs.Level_323Code.GDGoRightObjects3.length = 0;
gdjs.Level_323Code.GDGoLeftObjects1.length = 0;
gdjs.Level_323Code.GDGoLeftObjects2.length = 0;
gdjs.Level_323Code.GDGoLeftObjects3.length = 0;
gdjs.Level_323Code.GDLadderObjects1.length = 0;
gdjs.Level_323Code.GDLadderObjects2.length = 0;
gdjs.Level_323Code.GDLadderObjects3.length = 0;
gdjs.Level_323Code.GDPlayerHitBoxObjects1.length = 0;
gdjs.Level_323Code.GDPlayerHitBoxObjects2.length = 0;
gdjs.Level_323Code.GDPlayerHitBoxObjects3.length = 0;
gdjs.Level_323Code.GDSlimeWalkObjects1.length = 0;
gdjs.Level_323Code.GDSlimeWalkObjects2.length = 0;
gdjs.Level_323Code.GDSlimeWalkObjects3.length = 0;
gdjs.Level_323Code.GDFlyObjects1.length = 0;
gdjs.Level_323Code.GDFlyObjects2.length = 0;
gdjs.Level_323Code.GDFlyObjects3.length = 0;
gdjs.Level_323Code.GDBackgroundObjectsObjects1.length = 0;
gdjs.Level_323Code.GDBackgroundObjectsObjects2.length = 0;
gdjs.Level_323Code.GDBackgroundObjectsObjects3.length = 0;
gdjs.Level_323Code.GDLifeObjects1.length = 0;
gdjs.Level_323Code.GDLifeObjects2.length = 0;
gdjs.Level_323Code.GDLifeObjects3.length = 0;
gdjs.Level_323Code.GDScoreObjects1.length = 0;
gdjs.Level_323Code.GDScoreObjects2.length = 0;
gdjs.Level_323Code.GDScoreObjects3.length = 0;
gdjs.Level_323Code.GDCoinObjects1.length = 0;
gdjs.Level_323Code.GDCoinObjects2.length = 0;
gdjs.Level_323Code.GDCoinObjects3.length = 0;
gdjs.Level_323Code.GDCoinIconObjects1.length = 0;
gdjs.Level_323Code.GDCoinIconObjects2.length = 0;
gdjs.Level_323Code.GDCoinIconObjects3.length = 0;
gdjs.Level_323Code.GDLeftButtonObjects1.length = 0;
gdjs.Level_323Code.GDLeftButtonObjects2.length = 0;
gdjs.Level_323Code.GDLeftButtonObjects3.length = 0;
gdjs.Level_323Code.GDRightButtonObjects1.length = 0;
gdjs.Level_323Code.GDRightButtonObjects2.length = 0;
gdjs.Level_323Code.GDRightButtonObjects3.length = 0;
gdjs.Level_323Code.GDJumpButtonObjects1.length = 0;
gdjs.Level_323Code.GDJumpButtonObjects2.length = 0;
gdjs.Level_323Code.GDJumpButtonObjects3.length = 0;
gdjs.Level_323Code.GDArrowButtonsBgObjects1.length = 0;
gdjs.Level_323Code.GDArrowButtonsBgObjects2.length = 0;
gdjs.Level_323Code.GDArrowButtonsBgObjects3.length = 0;
gdjs.Level_323Code.GDCheckpointObjects1.length = 0;
gdjs.Level_323Code.GDCheckpointObjects2.length = 0;
gdjs.Level_323Code.GDCheckpointObjects3.length = 0;
gdjs.Level_323Code.GDTopButtonObjects1.length = 0;
gdjs.Level_323Code.GDTopButtonObjects2.length = 0;
gdjs.Level_323Code.GDTopButtonObjects3.length = 0;
gdjs.Level_323Code.GDPauseObjects1.length = 0;
gdjs.Level_323Code.GDPauseObjects2.length = 0;
gdjs.Level_323Code.GDPauseObjects3.length = 0;
gdjs.Level_323Code.GDBottomButtonObjects1.length = 0;
gdjs.Level_323Code.GDBottomButtonObjects2.length = 0;
gdjs.Level_323Code.GDBottomButtonObjects3.length = 0;
gdjs.Level_323Code.GDCheckpoint2Objects1.length = 0;
gdjs.Level_323Code.GDCheckpoint2Objects2.length = 0;
gdjs.Level_323Code.GDCheckpoint2Objects3.length = 0;
gdjs.Level_323Code.GDgameOverObjects1.length = 0;
gdjs.Level_323Code.GDgameOverObjects2.length = 0;
gdjs.Level_323Code.GDgameOverObjects3.length = 0;
gdjs.Level_323Code.GDNewObjectObjects1.length = 0;
gdjs.Level_323Code.GDNewObjectObjects2.length = 0;
gdjs.Level_323Code.GDNewObjectObjects3.length = 0;
gdjs.Level_323Code.GDNewObject2Objects1.length = 0;
gdjs.Level_323Code.GDNewObject2Objects2.length = 0;
gdjs.Level_323Code.GDNewObject2Objects3.length = 0;
gdjs.Level_323Code.GDNewObject3Objects1.length = 0;
gdjs.Level_323Code.GDNewObject3Objects2.length = 0;
gdjs.Level_323Code.GDNewObject3Objects3.length = 0;
gdjs.Level_323Code.GDNewObject4Objects1.length = 0;
gdjs.Level_323Code.GDNewObject4Objects2.length = 0;
gdjs.Level_323Code.GDNewObject4Objects3.length = 0;
gdjs.Level_323Code.GDNewObject5Objects1.length = 0;
gdjs.Level_323Code.GDNewObject5Objects2.length = 0;
gdjs.Level_323Code.GDNewObject5Objects3.length = 0;
gdjs.Level_323Code.GDNewObject6Objects1.length = 0;
gdjs.Level_323Code.GDNewObject6Objects2.length = 0;
gdjs.Level_323Code.GDNewObject6Objects3.length = 0;
gdjs.Level_323Code.GDDeath_95boxObjects1.length = 0;
gdjs.Level_323Code.GDDeath_95boxObjects2.length = 0;
gdjs.Level_323Code.GDDeath_95boxObjects3.length = 0;
gdjs.Level_323Code.GDtextObjects1.length = 0;
gdjs.Level_323Code.GDtextObjects2.length = 0;
gdjs.Level_323Code.GDtextObjects3.length = 0;
gdjs.Level_323Code.GDnumObjects1.length = 0;
gdjs.Level_323Code.GDnumObjects2.length = 0;
gdjs.Level_323Code.GDnumObjects3.length = 0;
gdjs.Level_323Code.GDNewObject7Objects1.length = 0;
gdjs.Level_323Code.GDNewObject7Objects2.length = 0;
gdjs.Level_323Code.GDNewObject7Objects3.length = 0;

gdjs.Level_323Code.eventsList22(runtimeScene);
return;

}

gdjs['Level_323Code'] = gdjs.Level_323Code;
